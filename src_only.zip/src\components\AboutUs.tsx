import React, { useState } from "react";
import { ZoomIn, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function AboutUs() {
  const [selectedCertificate, setSelectedCertificate] = useState<{
    title: string;
    issuer: string;
    image: string;
  } | null>(null);

  const certificates = [
    {
      title: "Сертификат официального представителя",
      issuer: "ОАО «Завод Промбурвод» / ГМС ГРУППА",
      // TODO: файл с кириллицей и пробелом в имени — риск при деплое на некоторые
      // хостинги/сборщики. Рекомендуется переименовать физический файл в
      // латиницу без пробелов, например "sertifikat-kompanii.png", и обновить путь ниже.
      image: "/сертификат компании.png"
    }
  ];

  return (
    <section id="about" className="py-16 sm:py-24 bg-white text-[#262626] overflow-hidden relative flex flex-col justify-center">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 2xl:px-12 relative z-10 w-full">

        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: -15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-10 sm:mb-12"
        >
          <h2 className="font-heading font-black text-2xl sm:text-3xl md:text-4xl lg:text-5xl text-[#262626] tracking-tight leading-tight uppercase">
            ООО «БелТехКомпания»
            <span className="block text-[#f5901e] my-1">надежный партнер</span>
            в электромонтаже и отоплении
          </h2>
          <div className="w-24 h-1.5 bg-[#f5901e] mt-4 rounded-full" />
        </motion.div>

        {/* Photo + Description Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-14 items-center mb-14">
          {/* Photo Left */}
          <motion.div
            id="about-photo-container"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="lg:col-span-6 relative"
          >
            <div className="w-full rounded-2xl overflow-hidden shadow-xl border border-neutral-200/90 bg-neutral-900 group">
              {/*
                TODO: временное стоковое фото (Unsplash) — заменить на реальное фото
                команды/объекта БелТехКомпания. alt намеренно не утверждает, что это
                снимок именно вашей компании, пока фото не заменено на настоящее.
              */}
              <img
                src="https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?auto=format&fit=crop&w=900&q=75"
                alt="Инженерные и электромонтажные работы — иллюстративное фото"
                className="w-full h-[320px] sm:h-[400px] lg:h-[440px] object-cover opacity-95 group-hover:scale-105 transition-transform duration-700"
                loading="eager"
                decoding="async"
                referrerPolicy="no-referrer"
              />
            </div>
          </motion.div>

          {/* Description Text Right */}
          <motion.div
            id="about-content"
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="lg:col-span-6 flex flex-col justify-center space-y-4"
          >
            <p className="font-sans text-neutral-700 text-base sm:text-lg md:text-xl leading-relaxed font-normal">
              Мы — динамично развивающаяся компания из г. Ивацевичи, объединяющая профессиональный инженерный электромонтаж, монтаж и сервисное обслуживание систем отопления, а также собственную розничную сеть материалов.
            </p>
            <p className="font-sans text-neutral-600 text-base sm:text-lg leading-relaxed font-normal">
              Выполняем полный комплекс инженерных и строительно-монтажных работ «под ключ» с гарантийным обслуживанием и официальной исполнительной документацией.
            </p>
          </motion.div>
        </div>

        {/* Certificates Section Centered */}
        <div className="mb-8 pt-8 border-t border-neutral-200">
          <div className="text-center mb-8">
            <h3 className="font-heading font-extrabold text-xl sm:text-2xl uppercase tracking-tight text-[#262626]">
              Сертификаты и дилерские соглашения
            </h3>
            <p className="text-xs sm:text-sm text-neutral-500 mt-1">
              Официальный статус и подтвержденная квалификация
            </p>
          </div>

          <div className="flex justify-center">
            {certificates.map((cert, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4 }}
                onClick={() => setSelectedCertificate(cert)}
                className="group relative bg-[#f8f8f6] border border-neutral-200/90 hover:border-[#f5901e] rounded-2xl overflow-hidden shadow-xs hover:shadow-xl transition-all cursor-pointer flex flex-col max-w-md w-full"
              >
                {/* Image Wrap */}
                <div className="relative aspect-[4/3] bg-neutral-900 overflow-hidden flex items-center justify-center p-2">
                  <img
                    src={cert.image}
                    alt={cert.title}
                    className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-neutral-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 text-white font-medium text-sm cursor-pointer">
                    <ZoomIn className="w-5 h-5 text-[#f5901e]" />
                    <span>Увеличить</span>
                  </div>
                </div>

                {/* Info Centered */}
                <div className="p-5 flex flex-col items-center text-center">
                  <span className="text-xs font-semibold text-[#f5901e] uppercase tracking-wider mb-1">
                    {cert.issuer}
                  </span>
                  <h4 className="font-heading font-bold text-base text-[#262626] group-hover:text-[#f5901e] transition-colors leading-snug">
                    {cert.title}
                  </h4>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

      </div>

      {/* Lightbox Modal without internal scroll and without 'Open original' button */}
      <AnimatePresence>
        {selectedCertificate && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedCertificate(null)}
            className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md p-4 sm:p-8 flex items-center justify-center cursor-pointer"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="relative bg-neutral-900 border border-neutral-800 rounded-2xl max-w-3xl w-full overflow-hidden shadow-2xl flex flex-col cursor-default"
            >
              {/* Header */}
              <div className="p-4 sm:p-5 bg-neutral-900 border-b border-neutral-800 flex items-center justify-between text-white">
                <div>
                  <span className="text-xs font-bold text-[#f5901e] uppercase tracking-wider block">
                    {selectedCertificate.issuer}
                  </span>
                  <h3 className="font-heading font-extrabold text-base sm:text-lg">
                    {selectedCertificate.title}
                  </h3>
                </div>
                <button
                  onClick={() => setSelectedCertificate(null)}
                  className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-full transition-colors cursor-pointer"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Certificate Image View - Clean fit without internal scrollbar */}
              <div className="p-4 sm:p-6 flex items-center justify-center bg-neutral-950 overflow-hidden">
                <img
                  src={selectedCertificate.image}
                  alt={selectedCertificate.title}
                  className="max-h-[75vh] w-auto max-w-full object-contain rounded-lg shadow-lg border border-neutral-800"
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}